use super::*;
use ledger_api::{
    client::{ClientSeed, LedgerClient},
    v1,
};
use ledger_export_adapters::v1::DecisionEvent;
use ledger_recovery::{Journal, Spec};
use prost::Message as _;
use rdkafka::{
    ClientConfig, Message, Offset, TopicPartitionList,
    consumer::{BaseConsumer, Consumer},
    mocking::MockCluster,
};

fn receive(consumer: &BaseConsumer) -> DecisionEvent {
    tokio::task::block_in_place(|| {
        let deadline = std::time::Instant::now() + WAIT;
        while std::time::Instant::now() < deadline {
            if let Some(Ok(message)) = consumer.poll(Duration::from_millis(100)) {
                let event = DecisionEvent::decode(message.payload().unwrap()).unwrap();
                assert_eq!(message.key().unwrap(), event.event_id.as_bytes());
                return event;
            }
        }
        panic!("no learner event arrived before deadline")
    })
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn learner_cli_archives_and_publishes_after_quorum_ack_and_restart() {
    let mut peers = Cluster::with_ids([1, 2, 3, 4]).await;
    let mut public = Cluster::new().await;
    let external = TempDir::new().unwrap();
    let path = external.path().join("archive");
    let configs = write_topology(&peers, Some((&public, &path)), Some(4));
    let topic = format!(
        "learner-cli-{}",
        peers
            .directory
            .path()
            .file_name()
            .unwrap()
            .to_str()
            .unwrap()
            .trim_start_matches('.')
    );
    let mock;
    let brokers = match std::env::var("LEDGER_TEST_KAFKA_BROKERS") {
        Ok(server) => {
            use rdkafka::admin::{AdminClient, AdminOptions, NewTopic, TopicReplication};
            let admin: AdminClient<_> = ClientConfig::new()
                .set("bootstrap.servers", &server)
                .create()
                .unwrap();
            let topics = [NewTopic::new(&topic, 1, TopicReplication::Fixed(1))];
            let result = admin
                .create_topics(&topics, &AdminOptions::new())
                .await
                .unwrap();
            assert!(result[0].is_ok(), "{result:?}");
            server
        }
        Err(_) => {
            mock = MockCluster::new(1).unwrap();
            mock.create_topic(&topic, 1, 1).unwrap();
            mock.bootstrap_servers()
        }
    };
    let learner_config = &configs[&4];
    let source = fs::read_to_string(learner_config).unwrap();
    let sinks = format!(
        r#"{source}
[export.archive]
kind = "posix"
path = "{}"

[export.publisher]
kind = "kafka"
brokers = "{brokers}"
topic = "{topic}"
partition = 0

[checkpoint]
interval_entries = 1
"#,
        path.display()
    );
    fs::write(learner_config, &sinks).unwrap();
    Process::spawn("journal-init", learner_config)
        .wait_success()
        .await;
    for file in configs.values() {
        Process::spawn("init", file).wait_success().await;
    }
    let spec = Spec {
        ledger: BOOK.0,
        asset: "USD".into(),
        scale: 2,
    };
    let journal = Journal::open(&path, &spec).unwrap();
    let cert = leaf("backend.test", &public.ca, &public.ca_key);
    let client = LedgerClient::connect(
        public
            .members
            .iter()
            .map(|(&node, m)| ClientSeed {
                node,
                endpoint: format!("https://{}", m.addr),
                domain: m.domain.clone(),
            })
            .collect(),
        public.ca.pem().into_bytes(),
        cert.cert_pem,
        cert.key_pem,
    )
    .unwrap();
    for m in peers
        .members
        .values_mut()
        .chain(public.members.values_mut())
    {
        drop(m.listener.take());
    }
    fs::write(
        learner_config,
        format!(
            "{source}\n[export.archive]\nkind = \"noop\"\n[export.publisher]\nkind = \"noop\"\n"
        ),
    )
    .unwrap();
    let disabled = Process::spawn("run", learner_config);
    timeout(WAIT, async {
        while tokio::net::TcpStream::connect(peers.members[&4].addr)
            .await
            .is_err()
        {
            sleep(Duration::from_millis(25)).await;
        }
    })
    .await
    .expect("disabled learner did not start");
    disabled.stop().await;
    assert!(!peers.directory.path().join("n4/export").exists());
    fs::write(learner_config, sinks).unwrap();

    // Exercise the minimum voting majority. The third voter and the learner are both offline.
    let first = Process::spawn("run", &configs[&1]);
    let second = Process::spawn("run", &configs[&2]);
    let account = v1::CreateAccountRequest {
        ledger_id: BOOK.0.to_string(),
        request_id: "100".into(),
        account_id: "52".into(),
        code: 27,
        normal: v1::Side::Credit.into(),
        bounds: None,
    };
    let create = |request| client.create_account(request, Instant::now() + WAIT);
    let accepted = create(account.clone()).await.unwrap();
    assert!(matches!(
        accepted.result,
        Some(v1::decision::Result::Accepted(_))
    ));
    assert_eq!(create(account.clone()).await.unwrap(), accepted);
    assert!(
        client
            .get_account(
                v1::GetAccountRequest {
                    ledger_id: BOOK.0.to_string(),
                    account_id: "52".into()
                },
                Instant::now() + WAIT
            )
            .await
            .unwrap()
            .account
            .is_some()
    );
    let destination = create(v1::CreateAccountRequest {
        request_id: "102".into(),
        account_id: "53".into(),
        ..account.clone()
    })
    .await
    .unwrap();
    let transfer = api::post_request(
        103,
        v1::funding::Kind::Explicit(v1::ExplicitFunding {
            lines: vec![
                api::line(52, v1::Side::Debit, "70"),
                api::line(53, v1::Side::Credit, "70"),
            ],
        }),
    );
    let posted = client
        .post_entry(transfer, Instant::now() + WAIT)
        .await
        .unwrap();
    assert!(matches!(
        &posted.result,
        Some(v1::decision::Result::Accepted(v1::Outcome {
            kind: Some(v1::outcome::Kind::Posted(_))
        }))
    ));
    assert_eq!(journal.head().unwrap().index, 0);

    let mut assignment = TopicPartitionList::new();
    assignment
        .add_partition_offset(&topic, 0, Offset::Beginning)
        .unwrap();
    let consumer: BaseConsumer = ClientConfig::new()
        .set("bootstrap.servers", &brokers)
        .set("group.id", &topic)
        .set("enable.auto.commit", "false")
        .create()
        .unwrap();
    consumer.assign(&assignment).unwrap();
    let detached = external.path().join("detached");
    fs::rename(&path, &detached).unwrap();
    let learner = Process::spawn("run", learner_config);
    // Local checkpoint creation proves the learner is applying Raft with the archive offline.
    await_seal(&peers.directory.path().join("n4")).await;
    assert_eq!(
        Journal::open(&detached, &spec)
            .unwrap()
            .head()
            .unwrap()
            .index,
        0
    );
    fs::rename(&detached, &path).unwrap();
    let created = receive(&consumer);
    assert_eq!(created.request_id, "100");
    assert_eq!(created.decision, Some(accepted));
    assert!(journal.head().unwrap().index >= created.raft_index);
    let second_account = receive(&consumer);
    assert_eq!(second_account.request_id, "102");
    assert_eq!(second_account.decision, Some(destination));
    let posting = receive(&consumer);
    assert_eq!(posting.request_id, "103");
    assert_eq!(posting.decision, Some(posted));
    assert!(journal.head().unwrap().index >= posting.raft_index);
    learner.stop().await;

    let rejected = create(v1::CreateAccountRequest {
        request_id: "101".into(),
        ..account
    })
    .await
    .unwrap();
    assert!(matches!(
        rejected.result,
        Some(v1::decision::Result::Rejected(_))
    ));
    let learner = Process::spawn("run", learner_config);
    let duplicate_account = receive(&consumer);
    assert_eq!(duplicate_account.request_id, "101");
    assert_eq!(duplicate_account.decision, Some(rejected));
    assert!(duplicate_account.raft_index > posting.raft_index);
    assert!(journal.head().unwrap().index >= duplicate_account.raft_index);
    learner.stop().await;
    first.stop().await;
    second.stop().await;
    let cut = journal.fence(&journal.head().unwrap()).unwrap();
    let replacement = ReplicaConfig {
        node: 1,
        cluster: CLUSTER + 1,
        voters: vec![1, 2, 3],
        ledger: BOOK,
        asset: "USD".into(),
        scale: 2,
    }
    .with_learner(4);
    let restored = Replica::restore(
        &external.path().join("replacement"),
        replacement,
        &journal,
        &cut,
    )
    .unwrap();
    assert!(
        restored
            .decision(RequestId(100))
            .unwrap()
            .unwrap()
            .outcome
            .is_ok()
    );
    assert!(
        restored
            .decision(RequestId(101))
            .unwrap()
            .unwrap()
            .outcome
            .is_err()
    );
    let entry = restored.entry(ledger_core::EntryId(1)).unwrap().unwrap();
    assert_eq!(
        entry.lines.as_ref(),
        &[
            Line::debit(AccountId::new(BOOK, 52), 70),
            Line::credit(AccountId::new(BOOK, 53), 70)
        ]
    );
    assert_eq!(
        restored
            .account(AccountId::new(BOOK, 52))
            .unwrap()
            .unwrap()
            .code(),
        27
    );
}
