use std::collections::BTreeMap;
use std::future::pending;
use std::time::Duration;

use ledger_replica::{CheckpointRef, Replica};
use serde::Deserialize;
use tokio::sync::oneshot;
use tokio::task::JoinHandle;
use tokio::time::Instant;

use crate::NodeError;

#[derive(Clone, Copy, Debug, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct CheckpointPolicy {
    /// Number of applied Raft entries between local checkpoints. Zero allows
    /// manual checkpoints only.
    pub interval_entries: u64,
    /// Keep this many entries preceding a sealed checkpoint available for
    /// ordinary peer replication. Larger gaps can use a snapshot.
    pub retained_entries: u64,
}

impl Default for CheckpointPolicy {
    fn default() -> Self {
        Self {
            interval_entries: 65_536,
            retained_entries: 8_192,
        }
    }
}

pub(crate) type Reply = oneshot::Sender<Result<CheckpointRef, NodeError>>;

struct SnapshotTail {
    term: u64,
    cut: u64,
    expires: Instant,
}

pub(crate) struct Checkpoints {
    pub(crate) policy: CheckpointPolicy,
    pub(crate) last_index: u64,
    pub(crate) error: Option<String>,
    retry_after: Instant,
    replication_cut: u64,
    tails: BTreeMap<u64, SnapshotTail>,
    task: Option<JoinHandle<Result<CheckpointRef, ledger_replica::ReplicaError>>>,
    reply: Option<Reply>,
}

impl Checkpoints {
    pub(crate) fn new(last_index: u64) -> Self {
        Self {
            policy: CheckpointPolicy::default(),
            last_index,
            error: None,
            retry_after: Instant::now(),
            replication_cut: 0,
            tails: BTreeMap::new(),
            task: None,
            reply: None,
        }
    }

    pub(crate) fn update_replication_cut(&mut self, replica: &Replica) -> Result<(), NodeError> {
        let mut cut = self.last_index.saturating_sub(self.policy.retained_entries);
        let now = Instant::now();
        self.tails.retain(|&peer, pin| {
            if pin.term != replica.term() || pin.expires <= now {
                return false;
            }
            if let Some(matched) = replica.matched_index(peer) {
                if matched >= pin.cut
                    && matched
                        >= replica
                            .last_index()
                            .saturating_sub(self.policy.retained_entries)
                {
                    return false;
                }
                cut = cut.min(pin.cut.max(matched));
                return true;
            }
            false
        });
        if cut > self.replication_cut {
            replica.compact_replication(cut)?;
            self.replication_cut = cut;
        }
        Ok(())
    }

    pub(crate) fn pin_snapshot_tail(&mut self, peer: u64, term: u64, cut: u64) {
        self.tails.insert(
            peer,
            SnapshotTail {
                term,
                cut,
                expires: Instant::now() + crate::transport::SNAPSHOT_OFFER_WINDOW,
            },
        );
    }

    pub(crate) fn report_snapshot(&mut self, peer: u64, term: u64, index: u64, success: bool) {
        if let Some(pin) = self.tails.get_mut(&peer)
            && (pin.term, pin.cut) == (term, index)
        {
            if success {
                // Keep ordinary append available while the receiver confirms
                // the new index and starts replicating its post-snapshot tail.
                pin.expires = Instant::now() + Duration::from_secs(60);
            } else {
                self.tails.remove(&peer);
            }
        }
    }

    pub(crate) fn schedule(&mut self, replica: &Replica) {
        let period = self.policy.interval_entries;
        if period == 0 || self.task.is_some() || Instant::now() < self.retry_after {
            return;
        }
        // Offset the initial captures of a new three-voter group. Most groups
        // apply similar indexes together and would otherwise flush together.
        let spacing = if self.last_index == 0 {
            let rank = replica
                .members()
                .position(|id| id == replica.node_id())
                .expect("configured local member") as u64;
            period - (period / replica.members().count() as u64) * rank
        } else {
            period
        };
        if replica.applied_index().saturating_sub(self.last_index) >= spacing {
            self.start(replica, None);
        }
    }

    pub(crate) fn start(&mut self, replica: &Replica, reply: Option<Reply>) {
        if self.task.is_some() {
            if let Some(reply) = reply {
                let _ = reply.send(Err(NodeError::Busy));
            }
            return;
        }
        self.reply = reply;
        let result = match replica.begin_checkpoint() {
            Ok(Some(task)) => {
                self.task = Some(tokio::task::spawn_blocking(move || task.finish()));
                return;
            }
            Ok(None) => replica
                .current_checkpoint()
                .map_err(NodeError::from)
                .and_then(|r| r.ok_or_else(|| NodeError::Invalid("checkpoint disappeared".into()))),
            Err(error) => Err(error.into()),
        };
        self.complete(result);
    }

    fn complete(&mut self, result: Result<CheckpointRef, NodeError>) {
        match &result {
            Ok(reference) => {
                self.last_index = reference.index;
                self.error = None;
            }
            Err(e) => {
                self.error = Some(e.to_string());
                self.retry_after = Instant::now() + Duration::from_secs(30);
                eprintln!("Local checkpoint failed: {e}");
            }
        }
        if let Some(reply) = self.reply.take() {
            let _ = reply.send(result);
        }
    }

    pub(crate) async fn poll(&mut self) {
        let Some(task) = self.task.as_mut() else {
            return pending().await;
        };
        let result = task
            .await
            .map_err(|_| NodeError::ThreadFailed)
            .and_then(|r| r.map_err(NodeError::from));
        self.task = None;
        self.complete(result);
    }

    pub(crate) async fn join(&mut self) {
        if self.task.is_some() {
            self.poll().await;
        }
    }
}
