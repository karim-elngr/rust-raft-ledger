use std::sync::Arc;
use std::thread;

use ledger_core::{
    Account, AccountId, Command, EntryId, Error, JournalEntry, LedgerId, Outcome, RequestId,
};
use ledger_replica::{AccountCacheStats, CheckpointRef, PreparedCommand, Replica, ReplicaError};
use tokio::net::TcpListener;
use tokio::sync::{OwnedSemaphorePermit, Semaphore, mpsc, oneshot, watch};
use tokio::time::{Instant, timeout_at};

use crate::checkpoints::{self, CheckpointPolicy};
use crate::protection::Protection;
use crate::reads::{Query, ReadRequest, Value};
use crate::runtime::Owner;
use crate::transport::{PeerConfig, PeerTransport, SnapshotResources};
use ledger_recovery::{Journal, JournalError};

const MAX_REQUESTS: usize = 512;
const MAX_REQUEST_BYTES: usize = 8 << 20;
const PEER_INBOX: usize = 32;
const CONTROL_QUEUE: usize = 64;

pub type Decision = Result<Outcome, Error>;

#[derive(Debug, thiserror::Error)]
pub enum NodeError {
    #[error("{0}")]
    Invalid(String),
    #[error("replica: {0}")]
    Replica(#[from] ReplicaError),
    #[error("gRPC transport: {0}")]
    Transport(#[from] tonic::transport::Error),
    #[error("node I/O: {0}")]
    Io(#[from] std::io::Error),
    #[error("independent journal: {0}")]
    Journal(#[from] JournalError),
    #[error("this node has no independent journal configured")]
    Unprotected,
    #[error("this cluster no longer owns the active recovery generation")]
    Fenced,
    #[error("node admission is full")]
    Busy,
    #[error("this voter is a follower (known leader {0:?})")]
    NotLeader(Option<u64>),
    #[error("leader changed after proposal; retry the original request ID")]
    LeadershipChanged,
    #[error("deadline elapsed; retry the original request ID to resolve the outcome")]
    Deadline,
    #[error("node is stopped")]
    Stopped,
    #[error("voter thread terminated unexpectedly")]
    ThreadFailed,
}

#[derive(Clone, Debug)]
pub struct NodeStatus {
    pub node: u64,
    pub is_leader: bool,
    pub is_learner: bool,
    pub leader_id: Option<u64>,
    pub term: u64,
    pub applied_index: u64,
    pub account_cache: AccountCacheStats,
    pub checkpoint_index: Option<u64>,
    pub recovered_from: u64,
    /// Last checkpoint this running process installed through Raft Ready.
    pub installed_snapshot: Option<u64>,
    pub last_snapshot_transfer: Option<crate::SnapshotTransferStats>,
    pub snapshot_maintenance_error: Option<String>,
    /// Remote voters and learner, with their confirmed match indexes on the current leader.
    pub peer_matches: Vec<(u64, u64)>,
    pub checkpoint_error: Option<String>,
    pub protected_index: Option<u64>,
    pub protection_error: Option<String>,
    pub raft_syncs: ledger_replica::RaftSyncStats,
    /// Independent journal appends published by this voter's completed verifier rounds.
    pub journal_append_publications: u64,
    #[cfg(feature = "batch-diagnostics")]
    /// Queue time of successfully proposed commands, summed across commands.
    pub proposal_queue_nanos: u128,
    pub proposed_batches: u64,
    pub proposed_commands: u64,
}

pub(crate) struct Admission {
    _slot: OwnedSemaphorePermit,
    _bytes: OwnedSemaphorePermit,
}

pub(crate) struct Waiter {
    pub id: RequestId,
    pub command: Command,
    pub deadline: Instant,
    pub reply: oneshot::Sender<Result<Decision, NodeError>>,
    _admission: Admission,
}

impl Waiter {
    pub fn finish(self, outcome: Result<Decision, NodeError>) {
        let _ = self.reply.send(outcome);
    }
}

pub(crate) struct Submission {
    #[cfg(feature = "batch-diagnostics")]
    pub enqueued: Instant,
    pub prepared: PreparedCommand,
    pub waiter: Waiter,
}

pub(crate) enum Control {
    Checkpoint(checkpoints::Reply),
    Read(Box<ReadRequest>),
    ExportFrontier(oneshot::Sender<u64>),
    ExportPage {
        after: ledger_export::Position,
        through: u64,
        reply: oneshot::Sender<Result<ledger_export::EventPage, ReplicaError>>,
    },
    Status(oneshot::Sender<NodeStatus>),
    Lookup {
        id: RequestId,
        command: Command,
        reply: oneshot::Sender<Option<Decision>>,
        _admission: Admission,
    },
}

pub(crate) fn enqueue<T>(sender: &mpsc::Sender<T>, message: T) -> Result<(), NodeError> {
    sender.try_send(message).map_err(|err| match err {
        mpsc::error::TrySendError::Closed(_) => NodeError::Stopped,
        mpsc::error::TrySendError::Full(_) => NodeError::Busy,
    })
}

/// Access to a running voter. Protected nodes gate all monetary results on
/// the independently durable committed prefix.
#[derive(Clone)]
pub struct NodeHandle {
    ledger: LedgerId,
    protected: bool,
    pub(crate) quorum_api: bool,
    slots: Arc<Semaphore>,
    bytes: Arc<Semaphore>,
    submissions: mpsc::Sender<Submission>,
    pub(crate) controls: mpsc::Sender<Control>,
}

impl NodeHandle {
    pub fn ledger_id(&self) -> LedgerId {
        self.ledger
    }
    pub fn is_protected(&self) -> bool {
        self.protected
    }

    pub(crate) fn channels(
        ledger: LedgerId,
    ) -> (Self, mpsc::Receiver<Submission>, mpsc::Receiver<Control>) {
        let (submissions, sub_rx) = mpsc::channel(MAX_REQUESTS);
        let (controls, control_rx) = mpsc::channel(CONTROL_QUEUE);
        (
            Self {
                ledger,
                protected: false,
                quorum_api: false,
                slots: Arc::new(Semaphore::new(MAX_REQUESTS)),
                bytes: Arc::new(Semaphore::new(MAX_REQUEST_BYTES)),
                submissions,
                controls,
            },
            sub_rx,
            control_rx,
        )
    }

    fn prepare(
        &self,
        id: RequestId,
        command: &Command,
    ) -> Result<(PreparedCommand, Admission), NodeError> {
        let slot = self
            .slots
            .clone()
            .try_acquire_owned()
            .map_err(|_| NodeError::Busy)?;
        let prepared = PreparedCommand::new(self.ledger, id, command)?;
        // The versioned command codec has a hard 1 MiB bound per entry.
        let bytes = self
            .bytes
            .clone()
            .try_acquire_many_owned(prepared.encoded_len() as u32)
            .map_err(|_| NodeError::Busy)?;
        Ok((
            prepared,
            Admission {
                _slot: slot,
                _bytes: bytes,
            },
        ))
    }

    /// Submit one command and wait for its Raft entry to apply on this leader.
    /// Losing the connection, leadership or a deadline can leave it committed.
    pub async fn submit_local(
        &self,
        id: RequestId,
        command: Command,
        deadline: Instant,
    ) -> Result<Decision, NodeError> {
        if deadline <= Instant::now() {
            return Err(NodeError::Deadline);
        }
        let (prepared, admission) = self.prepare(id, &command)?;
        let (reply, rx) = oneshot::channel();
        enqueue(
            &self.submissions,
            Submission {
                #[cfg(feature = "batch-diagnostics")]
                enqueued: Instant::now(),
                prepared,
                waiter: Waiter {
                    id,
                    command,
                    deadline,
                    reply,
                    _admission: admission,
                },
            },
        )?;
        timeout_at(deadline, rx)
            .await
            .map_err(|_| NodeError::Deadline)?
            .map_err(|_| NodeError::Stopped)?
    }

    /// Return a business decision only after local publication and a fresh
    /// confirmation from the active independent recovery journal.
    pub async fn submit_protected(
        &self,
        id: RequestId,
        command: Command,
        deadline: Instant,
    ) -> Result<Decision, NodeError> {
        if !self.protected {
            return Err(NodeError::Unprotected);
        }
        self.submit_local(id, command, deadline).await
    }

    async fn read(
        &self,
        query: Query,
        deadline: Instant,
        admission: Admission,
    ) -> Result<Value, NodeError> {
        let (reply, rx) = oneshot::channel();
        enqueue(
            &self.controls,
            Control::Read(Box::new(ReadRequest {
                query,
                reply,
                deadline,
                _admission: admission,
            })),
        )?;
        timeout_at(deadline, rx)
            .await
            .map_err(|_| NodeError::Deadline)?
            .map_err(|_| NodeError::Stopped)?
    }

    pub async fn protected_outcome(
        &self,
        id: RequestId,
        command: Command,
        deadline: Instant,
    ) -> Result<Option<Decision>, NodeError> {
        if !self.protected {
            return Err(NodeError::Unprotected);
        }
        if deadline <= Instant::now() {
            return Err(NodeError::Deadline);
        }
        let (_, admission) = self.prepare(id, &command)?;
        match self
            .read(Query::Outcome(id, command), deadline, admission)
            .await?
        {
            Value::Outcome(outcome) => Ok(outcome),
            _ => unreachable!("outcome query returns outcome"),
        }
    }

    async fn read_id(&self, query: Query, deadline: Instant) -> Result<Value, NodeError> {
        if !self.protected && !self.quorum_api {
            return Err(NodeError::Unprotected);
        }
        if deadline <= Instant::now() {
            return Err(NodeError::Deadline);
        }
        let bytes = match &query {
            Query::Accounts(ids) => {
                32 * u32::try_from(ids.len().max(1)).expect("bounded account list")
            }
            _ => 32,
        };
        let admission = Admission {
            _slot: self
                .slots
                .clone()
                .try_acquire_owned()
                .map_err(|_| NodeError::Busy)?,
            _bytes: self
                .bytes
                .clone()
                .try_acquire_many_owned(bytes)
                .map_err(|_| NodeError::Busy)?,
        };
        self.read(query, deadline, admission).await
    }

    pub async fn protected_account(
        &self,
        id: AccountId,
        deadline: Instant,
    ) -> Result<Option<Account>, NodeError> {
        if !self.protected {
            return Err(NodeError::Unprotected);
        }
        self.current_account(id, deadline).await
    }

    pub(crate) async fn current_account(
        &self,
        id: AccountId,
        deadline: Instant,
    ) -> Result<Option<Account>, NodeError> {
        match self.read_id(Query::Account(id), deadline).await? {
            Value::Account(account) => Ok(account),
            _ => unreachable!("account query returns an account"),
        }
    }

    pub async fn protected_entry(
        &self,
        id: EntryId,
        deadline: Instant,
    ) -> Result<Option<JournalEntry>, NodeError> {
        if !self.protected {
            return Err(NodeError::Unprotected);
        }
        self.current_entry(id, deadline).await
    }

    pub(crate) async fn current_entry(
        &self,
        id: EntryId,
        deadline: Instant,
    ) -> Result<Option<JournalEntry>, NodeError> {
        match self.read_id(Query::Entry(id), deadline).await? {
            Value::Entry(entry) => Ok(entry),
            _ => unreachable!("entry query returns a journal entry"),
        }
    }

    /// Read balances and policies from one protected applied view. Results
    /// preserve caller order, duplicate IDs and missing accounts.
    pub async fn protected_accounts(
        &self,
        ids: Vec<AccountId>,
        deadline: Instant,
    ) -> Result<Vec<Option<Account>>, NodeError> {
        if !self.protected {
            return Err(NodeError::Unprotected);
        }
        if ids.len() > 1024 {
            return Err(NodeError::Replica(ReplicaError::SizeLimit(
                "account list exceeds 1024 IDs",
            )));
        }
        match self.read_id(Query::Accounts(ids), deadline).await? {
            Value::Accounts(accounts) => Ok(accounts),
            _ => unreachable!("accounts query returns accounts"),
        }
    }

    /// Look up the original decision under a request ID, including a durable rejection.
    pub async fn protected_receipt(
        &self,
        id: RequestId,
        deadline: Instant,
    ) -> Result<Option<Decision>, NodeError> {
        if !self.protected {
            return Err(NodeError::Unprotected);
        }
        self.current_receipt(id, deadline).await
    }

    pub(crate) async fn current_receipt(
        &self,
        id: RequestId,
        deadline: Instant,
    ) -> Result<Option<Decision>, NodeError> {
        match self.read_id(Query::Receipt(id), deadline).await? {
            Value::Outcome(outcome) => Ok(outcome),
            _ => unreachable!("receipt query returns a decision"),
        }
    }

    /// Diagnostic nodes expose local state. Protected nodes use a quorum read
    /// and require a fresh journal confirmation.
    pub async fn local_outcome(
        &self,
        id: RequestId,
        command: Command,
    ) -> Result<Option<Decision>, NodeError> {
        if self.protected {
            return self
                .protected_outcome(
                    id,
                    command,
                    Instant::now() + std::time::Duration::from_secs(5),
                )
                .await;
        }
        let (_, admission) = self.prepare(id, &command)?;
        let (reply, rx) = oneshot::channel();
        enqueue(
            &self.controls,
            Control::Lookup {
                id,
                command,
                reply,
                _admission: admission,
            },
        )?;
        rx.await.map_err(|_| NodeError::Stopped)
    }

    pub async fn status(&self) -> Result<NodeStatus, NodeError> {
        let (reply, rx) = oneshot::channel();
        enqueue(&self.controls, Control::Status(reply))?;
        rx.await.map_err(|_| NodeError::Stopped)
    }

    /// Seal the current local applied view. A voter of either role can do this.
    pub async fn checkpoint(&self) -> Result<CheckpointRef, NodeError> {
        let (reply, rx) = oneshot::channel();
        enqueue(&self.controls, Control::Checkpoint(reply))?;
        rx.await.map_err(|_| NodeError::Stopped)?
    }
}

/// Embedded voter settings. Batching limits apply to local proposals and do
/// not change the on-disk format or a follower's ability to apply larger entries.
#[derive(Clone, Copy, Debug)]
pub struct NodeOptions {
    pub checkpoints: CheckpointPolicy,
    pub max_commands_per_entry: usize,
}

impl Default for NodeOptions {
    fn default() -> Self {
        Self {
            checkpoints: CheckpointPolicy::default(),
            max_commands_per_entry: ledger_replica::ProposalBatch::MAX_COMMANDS,
        }
    }
}

pub struct Node {
    feed: Option<Arc<dyn ledger_export::LedgerFeed>>,
    handle: NodeHandle,
    stop: watch::Sender<bool>,
    done: watch::Receiver<bool>,
    owner: Option<thread::JoinHandle<Result<(), NodeError>>>,
}

impl Node {
    /// Start a private peer listener for an initialized or reopened replica.
    pub async fn start(
        replica: Replica,
        config: PeerConfig,
        listener: TcpListener,
    ) -> Result<Self, NodeError> {
        Self::start_configured(replica, config, listener, None, CheckpointPolicy::default()).await
    }

    pub async fn start_protected(
        replica: Replica,
        config: PeerConfig,
        listener: TcpListener,
        journal: Journal,
    ) -> Result<Self, NodeError> {
        Self::start_configured(
            replica,
            config,
            listener,
            Some(journal),
            CheckpointPolicy::default(),
        )
        .await
    }

    pub async fn start_configured(
        replica: Replica,
        config: PeerConfig,
        listener: TcpListener,
        journal: Option<Journal>,
        checkpoints: CheckpointPolicy,
    ) -> Result<Self, NodeError> {
        Self::start_with_options(
            replica,
            config,
            listener,
            journal,
            NodeOptions {
                checkpoints,
                ..NodeOptions::default()
            },
        )
        .await
    }

    pub async fn start_with_options(
        replica: Replica,
        config: PeerConfig,
        listener: TcpListener,
        journal: Option<Journal>,
        options: NodeOptions,
    ) -> Result<Self, NodeError> {
        if !(1..=ledger_replica::ProposalBatch::MAX_COMMANDS)
            .contains(&options.max_commands_per_entry)
        {
            return Err(NodeError::Invalid(
                "max_commands_per_entry must be within the Raft batch limit".into(),
            ));
        }
        if journal.is_some() && replica.learner_id().is_some() {
            return Err(NodeError::Invalid(
                "synchronous protection requires the three-voter topology".into(),
            ));
        }
        let Some(journal) = journal else {
            return Self::start_with(replica, config, listener, None, options).await;
        };
        let (replica, verifier) = tokio::task::spawn_blocking(move || {
            let verifier = ledger_replica::JournalVerifier::open(&replica, journal)?;
            Ok::<_, NodeError>((replica, verifier))
        })
        .await
        .map_err(|_| NodeError::ThreadFailed)??;
        let protection = Protection::new(verifier);
        Self::start_with(replica, config, listener, Some(protection), options).await
    }

    async fn start_with(
        replica: Replica,
        config: PeerConfig,
        listener: TcpListener,
        protection: Option<Protection>,
        options: NodeOptions,
    ) -> Result<Self, NodeError> {
        let mut members: Vec<_> = config.peers.iter().map(|p| p.node).collect();
        members.push(config.node);
        members.sort_unstable();
        let mut expected: Vec<_> = replica.members().collect();
        expected.sort_unstable();
        if config.cluster != replica.cluster_id()
            || config.node != replica.node_id()
            || members != expected
        {
            return Err(NodeError::Invalid(
                "peer configuration differs from durable group membership".into(),
            ));
        }
        let (mut handle, sub_rx, control_rx) = NodeHandle::channels(replica.ledger_id());
        handle.protected = protection.is_some();
        handle.quorum_api = replica.learner_id().is_some() && !replica.is_learner();
        let feed = replica
            .is_learner()
            .then(|| crate::export::feed(&replica, &handle));
        let (peer_tx, peer_rx) = mpsc::channel(PEER_INBOX);
        let (failure_tx, failure_rx) = mpsc::channel(8);
        let (snapshot_tx, snapshot_rx) = mpsc::channel(8);
        let snapshots = SnapshotResources {
            files: replica.snapshot_files()?,
            history: replica.snapshot_history(),
            events: snapshot_tx,
        };
        let (stop, stop_rx) = watch::channel(false);
        let id = config.node;
        let transport = PeerTransport::start(
            config,
            listener,
            peer_tx,
            failure_tx,
            snapshots,
            stop_rx.clone(),
        )
        .await?;
        let runtime = tokio::runtime::Handle::current();
        let mut driver = Owner::new(
            replica,
            sub_rx,
            control_rx,
            peer_rx,
            failure_rx,
            snapshot_rx,
        );
        driver.protection = protection;
        driver.checkpoints.policy = options.checkpoints;
        driver.max_commands_per_entry = options.max_commands_per_entry;
        let (done_tx, done) = watch::channel(false);
        let owner = thread::Builder::new()
            .name(format!("ledger-voter-{id}"))
            .spawn(move || {
                let result = runtime.block_on(async move {
                    let result = driver.run(&transport, stop_rx).await;
                    transport.shutdown().await;
                    if let Some(p) = driver.protection.as_mut() {
                        p.join().await;
                    }
                    driver.checkpoints.join().await;
                    result
                });
                done_tx.send_replace(true);
                result
            })?;
        Ok(Self {
            feed,
            handle,
            stop,
            done,
            owner: Some(owner),
        })
    }

    /// Bounded reads of this learner's applied decisions and original Raft WAL.
    /// Invoke the synchronous feed from a blocking worker thread.
    pub fn learner_feed(&self) -> Option<Arc<dyn ledger_export::LedgerFeed>> {
        self.feed.clone()
    }

    pub fn handle(&self) -> NodeHandle {
        self.handle.clone()
    }

    /// Observe unsolicited listener or voter termination. Call shutdown to join
    /// the owner and retrieve the original error.
    pub async fn wait_stopped(&self) {
        let mut done = self.done.clone();
        let _ = done.wait_for(|finished| *finished).await;
    }

    /// Wait for the voter thread to release both RocksDB directories and sockets.
    pub async fn shutdown(mut self) -> Result<(), NodeError> {
        self.stop.send_replace(true);
        let owner = self.owner.take().expect("node owns its voter thread");
        tokio::task::spawn_blocking(move || owner.join())
            .await
            .map_err(|_| NodeError::ThreadFailed)?
            .map_err(|_| NodeError::ThreadFailed)?
    }
}

impl Drop for Node {
    fn drop(&mut self) {
        self.stop.send_replace(true);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ledger_core::{Balance, Bounds, Side};

    fn command() -> Command {
        Command::CreateAccount {
            account: ledger_core::AccountId::new(LedgerId(1), 8),
            code: 3,
            normal: Side::Credit,
            bounds: Bounds {
                min: Some(Balance::default()),
                max: None,
            },
        }
    }

    #[tokio::test]
    async fn expired_requests_never_enter_the_proposal_queue() {
        let (handle, mut submissions, _controls) = NodeHandle::channels(LedgerId(1));
        let result = handle
            .submit_local(RequestId(1), command(), Instant::now())
            .await;
        assert!(matches!(result, Err(NodeError::Deadline)));
        assert!(matches!(
            submissions.try_recv(),
            Err(mpsc::error::TryRecvError::Empty)
        ));
    }

    #[test]
    fn large_commands_exhaust_bytes_before_request_slots() {
        use ledger_core::{AccountId, Funding, Line};
        let (handle, _, _) = NodeHandle::channels(LedgerId(1));
        let account = AccountId::new(LedgerId(1), 7);
        let command = Command::Post {
            funding: Funding::Explicit(vec![Line::debit(account, 10); 1024]),
            conditions: vec![],
            corrects: None,
        };
        let mut held = Vec::new();
        let first = handle.prepare(RequestId(1), &command).unwrap();
        let capacity = MAX_REQUEST_BYTES / first.0.encoded_len();
        assert!(capacity < MAX_REQUESTS);
        held.push(first);
        for _ in 1..capacity {
            held.push(handle.prepare(RequestId(1), &command).unwrap());
        }
        assert!(matches!(
            handle.prepare(RequestId(1), &command),
            Err(NodeError::Busy)
        ));
        drop(held.pop());
        assert!(handle.prepare(RequestId(1), &command).is_ok());
    }

    #[test]
    fn in_flight_commands_keep_their_admission_budget() {
        let (handle, _, _) = NodeHandle::channels(LedgerId(1));
        let mut held = Vec::new();
        for _ in 0..MAX_REQUESTS {
            held.push(handle.prepare(RequestId(1), &command()).unwrap());
        }
        assert!(matches!(
            handle.prepare(RequestId(2), &command()),
            Err(NodeError::Busy)
        ));
        drop(held.pop());
        assert!(handle.prepare(RequestId(2), &command()).is_ok());
    }
}
