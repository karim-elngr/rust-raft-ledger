//! POSIX recovery-journal and Apache Kafka adapters for the asynchronous ledger exporter.
mod event;
mod kafka;
mod posix;

pub mod v1 {
    include!(concat!(env!("OUT_DIR"), "/ledger.export.v1.rs"));
}
pub use kafka::KafkaPublisher;
pub use posix::PosixArchive;
